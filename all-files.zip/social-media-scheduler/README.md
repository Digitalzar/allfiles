# Social Media Scheduler — Setup & Operations Guide

## 1) Architecture

Yeh **container-bound Google Apps Script** project hai. Google Sheet database hai; Apps Script validation, workflow, queue, triggers, email, Calendar aur official API calls handle karta hai. `index.html` same UI ko Sheet sidebar aur deployed web app dono mein chalata hai.

```text
Sidebar / Web app
       │ google.script.run
       ▼
Code.gs ── Lock + validation + RBAC
   ├── Google Sheets (system of record)
   ├── Time triggers (scheduler/reports)
   ├── MailApp + CalendarApp
   ├── Drive (read media for YouTube)
   └── Official APIs only
         ├── YouTube Data API v3
         └── Meta Graph API (Instagram/Facebook)
```

### Truthful publishing rule

- **DIRECT**: Tabhi use hota hai jab `AUTO_PUBLISH_ENABLED=TRUE`, platform mode `DIRECT`, required permissions, official API, aur secure Script Properties configured hon.
- **MANUAL**: Reminder, checklist, caption/media reference aur platform-opening link deta hai. Yeh success mark **nahi** karta.
- Manual post ko `Confirm manual publish` button se **verified HTTPS Published URL** ke saath confirm karna hota hai.
- YouTube/Meta API response mein confirmed ID/permalink na mile to attempt failure/retry hota hai; fake success kabhi nahi.

### Sheet structure

| Sheet | Purpose | Key controls |
|---|---|---|
| Dashboard | Live KPIs, distribution, weekly stats, upcoming queue | Script refresh |
| Content Database | Main 20-column CMS specified in brief | Dropdowns, filter, validations, conditional colors |
| Publishing Calendar | Chronological scheduled view | Auto-generated; edit CMS, not this sheet |
| Platform Settings | Account, formats, mode, opening URL, reminder, retries | No secrets stored here |
| Team and Permissions | Admin/Editor/Approver/Viewer access matrix | Application-level RBAC |
| Activity Log | Immutable-style status/activity audit | Timestamp, old/new state, user, comment |
| Publishing Queue | Attempts, retry timing, outcome/error | Scheduler-managed |
| Reports | Weekly KPI snapshots | Trigger-managed |
| Configuration | Non-sensitive operational settings | Time zone, email, retries, switches |

Koi extra sheet required nahi hai. API secrets **Script Properties** mein rahenge, spreadsheet cells mein nahi.

### Workflow

```text
Idea → Content Planning → In Production → Ready for Review
                                      ↘ Revision Required → In Production
Ready for Review → Approved → Scheduled → Publishing → Published
                 ↘ Rejected       ↘ Paused       ↘ Failed → retry
```

Transition map `SMS.TRANSITIONS` mein centralized hai. Sidebar aur direct sheet edit dono invalid transition block karte hain. Direct sheet edits default audit comment use karte hain; review decisions sidebar/web app se comment ke saath karein.

## 2) Beginner setup — step by step

### A. Google Sheet aur Apps Script project

1. Ek blank Google Sheet banayein.
2. Sheet mein **Extensions → Apps Script** open karein.
3. Apps Script editor mein files create/replace karein:
   - `Code.gs`
   - `index.html`
   - `Styles.html`
   - `JavaScript.html`
   - `appsscript.json` (Project Settings mein “Show appsscript.json” on karein)
4. Is package ke matching file contents paste karein.
5. `setupSystem()` select karke **Run** karein. Google authorization prompts approve karein.
6. Sheet reload karein. `Social Scheduler` custom menu visible hoga.
7. `Team and Permissions` mein actual user emails aur roles verify/add karein.
8. `Configuration` mein notification emails aur operational values edit karein.
9. Menu se **Install / Repair Triggers** ek baar run karein.

`setupSystem()` idempotent repair function hai: missing sheets/headers/settings/validation/triggers banata hai, existing content rows delete nahi karta.

### B. Web app deployment

1. Apps Script editor mein **Deploy → New deployment → Web app**.
2. Execute mode carefully choose karein:
   - **User accessing the web app**: per-user Google identity/scopes; stricter multi-user option.
   - **Me**: owner scopes use honge; app RBAC helpful hai, lekin deployment access bahut carefully restrict karein.
3. Access ko organization/team tak restrict karein; public/anonymous access use na karein.
4. Deploy, authorize, aur generated deployment URL authorized users ko share karein.
5. Code update ke baad **Manage deployments → Edit → New version** deploy karein.

### C. Configuration keys

| Key | Default | Meaning |
|---|---:|---|
| `DEFAULT_TIME_ZONE` | `Asia/Kolkata` | New records ka default zone |
| `REMINDER_LEAD_MINUTES` | `60` | Upcoming reminder lead |
| `DAILY_SUMMARY_HOUR` | `8` | Daily email hour |
| `NOTIFICATION_EMAILS` | owner email | Comma-separated recipients |
| `CALENDAR_ID` | `primary` | Target Google Calendar |
| `CREATE_CALENDAR_EVENTS` | `TRUE` | Scheduled item par event create |
| `MAX_RETRIES_DEFAULT` | `3` | API attempts cap |
| `RETRY_DELAY_MINUTES` | `15` | Exponential backoff base |
| `MAX_ITEMS_PER_RUN` | `8` | Per-trigger execution safety cap |
| `AUTO_PUBLISH_ENABLED` | `FALSE` | Global safety switch |

`AUTO_PUBLISH_ENABLED` ko API tests complete hone ke baad hi `TRUE` karein.

### D. Team roles

- **Admin**: setup, triggers, delete, all workflow decisions.
- **Editor**: add/edit, production workflow, schedule, manual publish confirm.
- **Approver**: approve, reject, request revision, read content.
- **Viewer**: read-only UI/report access.

Google Sheet sharing permissions alag security layer hai. Spreadsheet Editors raw sheets/code-related data dekh sakte hain. Strict separation ke liye most users ko web app access dein, Sheet edit access sirf trusted operators ko dein. Apps Script mein true row-level Sheet security available nahi hai.

## 3) Files aur function guide (Hinglish)

### `Code.gs`

**Lifecycle / setup**

- `onOpen()` — Sheet ka custom menu banata hai.
- `onInstall()` — install ke baad menu initialize karta hai.
- `setupSystem()` — nine sheets, schema, defaults, validation, dashboard aur triggers setup/repair karta hai.
- `ensureSheet_()`, `styleHeader_()` — sheet/header ko repeat-safe tareeke se banate/style karte hain.
- `seedSettings_()` — platform, config aur owner role ke safe defaults add karta hai.
- `applyValidationsAndFormatting_()` — dropdowns, date formats, filters aur warning colors lagata hai.
- `buildDashboardSheet_()`, `refreshDashboardSheet_()` — native Sheet dashboard create/update karte hain.

**Web app / CRUD**

- `include()` — `Styles.html` aur `JavaScript.html` ko template mein include karta hai.
- `doGet()` — responsive web app serve karta hai.
- `showSidebar()` — same interface Sheet sidebar mein open karta hai.
- `getBootstrapData()` — UI options, current user, settings, KPIs aur first content page ek request mein deta hai.
- `listContent()`, `getContent()` — search/filter/detail data read karte hain.
- `saveContent()` — lock, validation, ID generation, duplicate check aur audit ke saath create/update karta hai.
- `deleteContent()` — Admin-only safe delete; Publishing/Published records block hote hain.
- `sanitizeContentInput_()`, `validateContentInput_()` — bad control characters, invalid enum/date/time/URL block karte hain.
- `getContentRecords_()`, `contentRowToObject_()`, `objectToContentRow_()` — Sheet rows aur UI objects convert karte hain.
- `checkDuplicateSchedule_()` — same platform/date/time collision prevent karta hai.

**Workflow / audit**

- `updateStatus()` — allowed transition, role, approval aur scheduling checks enforce karta hai.
- `approveContent()`, `requestRevision()` — approval convenience endpoints hain.
- `getActivity()`, `logActivity_()` — status change history read/write karte hain.
- `onEdit(e)` — direct Sheet status edit ko validate/log karta hai aur last-updated/ID maintain karta hai.

**Calendar / scheduler / notification**

- `getCalendarData()` — daily/weekly/monthly range data deta hai.
- `refreshCalendar_()` — Publishing Calendar sheet rebuild karta hai.
- `installTriggers()` — purane matching triggers remove karke exactly one scheduler, daily aur weekly trigger banata hai.
- `runScheduler()` — queue refresh, reminder aur due items process karta hai.
- `refreshPublishingQueue_()`, `upsertQueueItem_()` — eligible approved posts ko idempotently queue mein sync karte hain.
- `processQueueItem_()` — MANUAL checklist ya DIRECT official adapter chalata hai; attempts/retry/failure record karta hai.
- `updateQueueRow_()`, `getQueueRecords_()` — queue persistence helpers hain.
- `setContentStatusInternal_()`, `setContentPublished_()`, `setContentFailed_()` — scheduler-controlled state updates/audit karte hain.
- `sendUpcomingReminders_()`, `notifyApprovalPending_()` — deduplicated reminder/approval email bhejte hain.
- `sendDailySummary()`, `sendWeeklyReport()` — scheduled summaries aur report snapshots bhejte hain.
- `createCalendarEvent_()` — Content ID search se duplicate Calendar event avoid karta hai.
- `manualChecklistHtml_()`, `sendEmail_()` — safe checklist aur quota-aware email helper hain.

**Official publishing**

- `publishViaOfficialApi_()` — exact platform adapter route karta hai; unsupported platform par clear error deta hai.
- `publishYouTube_()` — Drive media blob ko official YouTube Advanced Service se upload karta hai.
- `publishInstagram_()` — official Meta Graph media container/publish flow; Reel processing poll karta hai.
- `publishFacebook_()` — official Graph feed/photo publishing flow; video intentionally manual hai.
- `metaRequest_()` — bearer auth, status check aur official API error parsing karta hai.
- `confirmManualPublished()` — human-verified URL ke baad hi manual item Published karta hai.

**Reports / utilities**

- `getDashboardData()` — KPIs, platform mix, weekly/monthly stats aur upcoming queue calculate karta hai.
- `exportContentCsv()` — current filters ka RFC-style escaped CSV return karta hai.
- `loadSampleData()` — duplicate-safe three beginner sample records add karta hai.
- `getPlatformSettings_()`, `getConfig_()` — non-sensitive settings read karte hain.
- `getCurrentUser_()`, `assertRole_()` — app-level RBAC enforce karte hain.
- `withDocumentLock_()` — simultaneous writes ko serialize karta hai.
- `zonedDate_()` — per-record IANA time zone wall time ko actual instant mein convert karta hai.
- Remaining `_` helpers IDs, dates, Drive IDs, CSV/HTML escaping aur truncation handle karte hain.

### Front-end files

- `index.html` — header, navigation, four views, forms aur dialogs ka accessible structure.
- `Styles.html` — responsive editorial command-center design; mobile/tablet/sidebar breakpoints included.
- `JavaScript.html` — Apps Script RPC wrapper, state, CRUD, filters, workflow actions, calendar, charts aur CSV download. Apps Script ke bahar open hone par sirf UI preview ke liye mock data dikhata hai; production writes kabhi mock nahi hote.
- `appsscript.json` — V8 runtime, minimum project features ke scopes, timezone aur YouTube Advanced Service declaration.

## 4) Daily use

1. Sidebar mein **New content** se record banayein.
2. Idea → planning → production → review move karein.
3. Approver comment ke saath Approve/Revision/Reject kare.
4. Approved record mein future date/time set karke `Scheduled` move karein.
5. MANUAL platform ko email/checklist milega. Post ke baad verified URL se confirm karein.
6. DIRECT platform ko scheduler official adapter se publish karega; API error par retry/alert/log milega.
7. Dashboard, calendar, Activity Log aur Queue review karein.

## 5) Official API integrations

### Secure properties

Apps Script **Project Settings → Script Properties** mein values add karein. In values ko source code, Sheet cells, screenshots ya client JavaScript mein kabhi na rakhein.

| Property | Used by | Required |
|---|---|---|
| `YOUTUBE_PRIVACY_STATUS` | YouTube | Optional: `private` recommended during test |
| `YOUTUBE_CATEGORY_ID` | YouTube | Optional; code default `22` |
| `META_ACCESS_TOKEN` | Instagram/Facebook | Long-lived Page/system-user token as allowed by Meta app setup |
| `META_IG_USER_ID` | Instagram | Professional Instagram account ID |
| `META_FB_PAGE_ID` | Facebook | Target Page ID |
| `META_GRAPH_VERSION` | Meta | Explicit supported version, e.g. value chosen from your Meta app dashboard |

Script Properties source-code encryption substitute nahi hain: project Editors script ke through access kar sakte hain. Editors ko minimum rakhein, token rotation policy rakhein, aur production ke liye separate deployment/project consider karein.

### YouTube / YouTube Shorts — implemented DIRECT adapter

1. Apps Script **Services** mein YouTube Data API v3 add/enable karein (manifest declaration included hai).
2. Linked Google Cloud project mein YouTube Data API enabled hona chahiye.
3. Deploying/using Google account ke paas target channel upload permission honi chahiye.
4. Media URL accessible Google Drive file ka link ho. Script `DriveApp` se blob read karta hai.
5. Pehle `YOUTUBE_PRIVACY_STATUS=private` ke saath test karein.
6. YouTube quota units limited hote hain; uploads expensive hote hain. Cloud console quota monitor karein.

Shorts ko YouTube API normal video upload ki tarah accept karta hai; actual Shorts classification media dimensions/duration aur current YouTube rules par depend karti hai. Code fake “Shorts accepted” claim nahi karta.

### Instagram / Reels — implemented official Meta adapter

Requirements:

- Professional Instagram account, connected Facebook Page aur Meta developer app.
- App review/live-mode permissions appropriate to your account/use case, commonly Instagram content publishing/basic access.
- Publicly reachable HTTPS media. Normal Drive sharing page direct media URL nahi hai.
- Image post: container → publish → permalink confirmation.
- Reel: video container → status polling → publish → permalink confirmation.

Meta Graph version code mein hard-code nahi hai; `META_GRAPH_VERSION` property required hai, taki deprecated version silently use na ho. Carousel adapter intentionally included nahi hai; us format ko MANUAL rakhein.

### Facebook Pages — implemented official Meta adapter

Text/link aur single-image Page post adapter included hai. Valid Page token, Page ID, app permissions/review aur Page task access required hain. Facebook video is build mein intentionally MANUAL hai. Successful state tabhi set hota hai jab API post ID aur `permalink_url` confirm kare.

### TikTok, LinkedIn, X — safe MANUAL default

- **TikTok**: Content Posting API approval, creator authorization, audit/status handling aur media transfer requirements account/app specific hain.
- **LinkedIn**: Community Management/app review, organization admin permissions aur media upload lifecycle required ho sakta hai.
- **X**: write-enabled user OAuth aur applicable API access/tier required hai; media upload alag flow hai.

In teen platforms ke liye current project reminder + checklist + opening link provide karta hai. Platform settings ko DIRECT kar dena adapter create nahi karta; scheduler clear failure देगा, success nahi. Approved official access milne ke baad `publishViaOfficialApi_()` mein dedicated adapter add karein, confirmed post URL/ID return karein, aur tests pass karne ke baad mode switch karein.

## 6) Security, reliability aur quotas

- **Least privilege**: Manifest current feature set ke scopes declare karta hai. Agar Calendar/email/YouTube remove karein to matching scope bhi remove kar sakte hain.
- **Locking**: Script lock concurrent create/status/queue collision reduce karta hai.
- **Input safety**: Server-side enum/date/time/URL validation; HTML/CSV escaping; API errors truncated.
- **Duplicate safety**: unique UUID-based Content ID, same platform/date/time collision check, queue upsert, trigger replacement, Calendar ID search, reminder property key.
- **Retries**: exponential backoff, per-platform max attempts, attempt/error timestamps.
- **Kill switch**: `AUTO_PUBLISH_ENABLED=FALSE` sab DIRECT settings ko effective MANUAL banata hai.
- **Quota awareness**: `MailApp.getRemainingDailyQuota()` checked hai. Apps Script, UrlFetch, Drive, Calendar, YouTube aur platform quotas account/project ke according change hote hain; official consoles/quota pages monitor karein.
- **Execution limits**: Ek run mein due items cap rakhein; heavy Reel processing aur large Drive uploads Apps Script execution limit hit kar sakte hain. Queue next trigger par continue hoti hai.
- **Audit caveat**: Sheet Editors Activity Log ko manually edit kar sakte hain. Strong compliance audit ke liye append-only external datastore/log sink required hoga.
- **Media privacy**: Meta publishing ko public media URL chahiye. Sensitive/unreleased asset ke public exposure risk ko assess karein.
- **Token hygiene**: short-lived test tokens production mein use na karein; expiration/rotation alerts external process se maintain karein.

### Manifest note

Time-driven trigger ke paas active spreadsheet context nahi hota, isliye stored spreadsheet ID ko open karne ke liye full `spreadsheets` scope required hai. `script.external_request` Meta calls ke liye, `drive.readonly` YouTube source asset ke liye, `calendar`, `script.send_mail`, `script.scriptapp`, `userinfo.email`, aur `youtube.upload` relevant features ke liye hain. Authorization behavior Google account/deployment mode par depend karta hai.

## 7) Testing checklist

### Smoke test

- [ ] `setupSystem()` completes; all nine sheets exist.
- [ ] Custom menu and sidebar open.
- [ ] Web app opens on desktop and mobile width.
- [ ] `Load Sample Data` adds exactly three records; second run does not duplicate.
- [ ] New content gets `CNT-YYYYMMDD-XXXXXX` ID, creation/updated timestamps.
- [ ] Platform/type/category/status dropdowns reject invalid values.
- [ ] Same platform/date/time second record is blocked.
- [ ] Search, platform filter, status filter and CSV export work.

### Workflow test

- [ ] Idea → Approved direct jump is blocked.
- [ ] Production → Review sets Approval Status to Pending and sends notification.
- [ ] Approver can approve; Editor without Approver role cannot.
- [ ] Scheduled transition without Approved state or date/time is blocked.
- [ ] Every accepted state change creates Activity Log row with old/new/user/comment.
- [ ] Revision and rejection require comment in UI.
- [ ] Published/Publishing delete is blocked.

### Scheduler test — MANUAL first

1. `AUTO_PUBLISH_ENABLED=FALSE` rakhein.
2. Future few-minutes record approve + schedule karein.
3. Menu se `Run Scheduler Now`.
4. Publishing Queue mein `MANUAL_DUE`/reminder state verify karein.
5. Record Published **na** hua ho — this is expected.
6. Dummy test platform post ka verified HTTPS URL use karke `Confirm manual publish`; then Published URL/status/log verify karein.

### DIRECT sandbox test

- [ ] Test/private account aur least-risk media use karein.
- [ ] Required service, permissions, token properties configured.
- [ ] Platform row `DIRECT`, global switch `TRUE` only during controlled test.
- [ ] Successful API response produces real Published URL.
- [ ] Invalid/expired credential produces queue error, notification and retry — Published nahi.
- [ ] Max attempts ke baad Content `Failed` aur queue `FAILED`.
- [ ] Duplicate triggers absent (Apps Script Triggers page mein only three project triggers).

### Sample data

Menu **Social Scheduler → Load Sample Data** three records banata hai: Instagram idea, LinkedIn planning, YouTube Shorts production. Yeh actual publishing attempt nahi karte.

## 8) Common errors aur troubleshooting

| Symptom | Cause | Fix |
|---|---|---|
| “Spreadsheet not configured” | Setup never ran / copied standalone | Script ko target Sheet se bind karke `setupSystem()` run karein |
| Sidebar blank/old | stale deployment or HTML error | Editor execution log check, Sheet reload; web app new version deploy |
| Permission denied | email missing/inactive/wrong role | Team sheet email/role/Active check; deployment identity mode verify |
| Active user email blank | deployment executes as owner / consumer identity limitation | Restricted domain deployment or execute-as-user mode use; access policy tighten |
| Invalid transition | workflow map violation | Current state ke allowed next state follow karein |
| Duplicate slot | same platform/date/time exists | time/platform change karein ya conflicting item pause/reject karein |
| Scheduler not running | trigger absent/authorization failed | Menu `Install / Repair Triggers`; Triggers/Executions page errors check |
| Emails missing | recipient blank, spam, quota, authorization | Configuration email, Mail quota and execution log check |
| Calendar event missing | bad Calendar ID/access/scope | Calendar ID and authorization verify; event failure scheduler ko block nahi karta |
| `YouTube is not defined` | Advanced Service absent | Apps Script Services mein YouTube Data API v3 enable karein |
| YouTube upload fails | Drive access, codec/size/quota/channel permission | Drive file ownership/access, API quota, channel role, Execution log check |
| Meta 400/401/403 | token, permissions, account link, version or media URL | Script Properties, app mode/review, Page/IG IDs, public HTTPS asset verify |
| Instagram container timeout | video still processing | Queue automatic retry karegi; media specs/Meta container status verify |
| Meta Drive URL rejected | Drive sharing page is not direct public media | Public HTTPS object storage/CDN media URL use karein |
| Queue keeps MANUAL | global switch false or platform mode manual | Controlled tests ke baad both switches set; credentials first |
| Apps Script timeout | too many due uploads / heavy media | per-run cap reduce, schedule spread karein; heavy uploads external worker par move karein |
| Sheet direct edit not logged | multi-cell paste/simple-trigger edge case | Workflow decisions UI se karein; Activity Log verify |

### Recovery procedure

1. `AUTO_PUBLISH_ENABLED=FALSE` set karke publishing freeze karein.
2. Publishing Queue aur Activity Log se affected Content IDs identify karein.
3. Official platform par actual post existence verify karein — blindly retry na karein.
4. Duplicate already published ho to verified URL se manual confirmation karein.
5. Credential/config fix karke only failed record ko allowed transition se Scheduled karein.
6. `Run Scheduler Now`, then queue/content/log verify karein.

## 9) Maintainability / scaling notes

- Header order change na karein; code fixed schema indices use karta hai.
- Adapter ko small dedicated function mein add karein aur `{success:true,url,id}` only after official confirmation return karein.
- High volume, large video upload, token refresh service, immutable audit, true row-level security aur cross-account publishing ke liye Apps Script se dedicated backend/cloud queue par migrate karein.
- Spreadsheet UI practical human workflow ke liye hai; API polling/high-frequency scheduler ke liye 5-minute trigger and quotas respect karein.
- Production change se pehle copied Sheet/script project mein test karein.

## 10) Deliverable map

All files isi package mein complete hain. Koi secret/token placeholder source code mein nahi diya gaya. Required values tables mein clearly listed hain. First safe run manual mode mein hota hai; direct publishing operator ke explicit configuration ke bina activate nahi hoti.
