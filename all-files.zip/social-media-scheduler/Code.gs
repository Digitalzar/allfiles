/**
 * Social Media Scheduler — Google Apps Script backend
 * Version: 1.0.0
 * Bind this project to a Google Sheet, then run setupSystem().
 */

// SECTION 1: Constants, schema, and lifecycle
const SMS = Object.freeze({
  VERSION: '1.0.0',
  DEFAULT_TZ: 'Asia/Kolkata',
  SHEETS: {
    DASHBOARD: 'Dashboard', CONTENT: 'Content Database', CALENDAR: 'Publishing Calendar',
    PLATFORMS: 'Platform Settings', TEAM: 'Team and Permissions', ACTIVITY: 'Activity Log',
    QUEUE: 'Publishing Queue', REPORTS: 'Reports', CONFIG: 'Configuration'
  },
  CONTENT_HEADERS: ['Content ID','Content Title','Platform','Content Type','Caption','Hashtags','Keywords','Media URL','Content Category','Campaign Name','Assigned Person','Creation Date','Scheduled Date','Scheduled Time','Time Zone','Approval Status','Publishing Status','Published URL','Error Message','Last Updated'],
  PLATFORMS: ['YouTube','YouTube Shorts','Instagram','Instagram Reels','Facebook Pages','TikTok','LinkedIn','X (Twitter)'],
  CONTENT_TYPES: ['Video','Short Video','Reel','Image','Carousel','Text','Story','Live','Article','Link'],
  CATEGORIES: ['Educational','Promotional','Entertainment','News','Community','Behind the Scenes','Product','Thought Leadership','Other'],
  APPROVALS: ['Not Submitted','Pending','Approved','Revision Required','Rejected'],
  STATUSES: ['Idea','Content Planning','In Production','Ready for Review','Approved','Scheduled','Publishing','Published','Revision Required','Rejected','Paused','Failed'],
  TRANSITIONS: {
    'Idea': ['Content Planning','Paused','Rejected'],
    'Content Planning': ['In Production','Paused','Rejected'],
    'In Production': ['Ready for Review','Paused','Rejected'],
    'Ready for Review': ['Approved','Revision Required','Rejected','Paused'],
    'Revision Required': ['In Production','Ready for Review','Rejected','Paused'],
    'Approved': ['Scheduled','Revision Required','Paused'],
    'Scheduled': ['Publishing','Approved','Paused','Failed'],
    'Publishing': ['Published','Failed'],
    'Failed': ['Scheduled','Publishing','Paused'],
    'Paused': ['Idea','Content Planning','In Production','Ready for Review','Approved','Scheduled','Rejected'],
    'Rejected': ['Idea','Content Planning'],
    'Published': []
  },
  ACTIVITY_HEADERS: ['Timestamp','Log ID','Content ID','Previous Status','New Status','Comment','Changed By','Source'],
  QUEUE_HEADERS: ['Queue ID','Content ID','Scheduled At','Platform','Mode','Queue Status','Attempts','Max Attempts','Last Attempt','Next Attempt','Result URL','Error Message','Updated At'],
  CAL_HEADERS: ['Scheduled At','Content ID','Content Title','Platform','Account','Content Type','Approval Status','Publishing Status','Assigned Person','Action'],
  PLATFORM_HEADERS: ['Platform','Account Name','Allowed Formats','Enabled','Publishing Mode','Platform Opening URL','Reminder Lead Minutes','Maximum Retries','Credential Status','Notes'],
  TEAM_HEADERS: ['Email','Name','Role','Active','Platforms','Notification Preference'],
  CONFIG_HEADERS: ['Key','Value','Description','Sensitive?'],
  REPORT_HEADERS: ['Generated At','Period','Metric','Platform','Value','Notes']
});

function onOpen() {
  SpreadsheetApp.getUi().createMenu('Social Scheduler')
    .addItem('Open Sidebar', 'showSidebar')
    .addItem('Open Dashboard', 'openDashboardSheet')
    .addSeparator()
    .addItem('Refresh Dashboard & Calendar', 'refreshSystemViews')
    .addItem('Run Scheduler Now', 'runScheduler')
    .addItem('Install / Repair Triggers', 'installTriggers')
    .addSeparator()
    .addItem('Setup / Repair System', 'setupSystem')
    .addItem('Load Sample Data', 'loadSampleData')
    .addToUi();
}

function onInstall() { onOpen(); }

// SECTION 2: Setup, validation, dashboard, and menu
function setupSystem() {
  return withDocumentLock_(function () {
    const ss = SpreadsheetApp.getActiveSpreadsheet();
    if (!ss) throw new Error('Is script ko target Google Sheet ke saath bind karke setupSystem() run karein.');
    PropertiesService.getScriptProperties().setProperty('SPREADSHEET_ID', ss.getId());
    ss.setSpreadsheetTimeZone(SMS.DEFAULT_TZ);
    ensureSheet_(ss, SMS.SHEETS.DASHBOARD, []);
    ensureSheet_(ss, SMS.SHEETS.CONTENT, SMS.CONTENT_HEADERS);
    ensureSheet_(ss, SMS.SHEETS.CALENDAR, SMS.CAL_HEADERS);
    ensureSheet_(ss, SMS.SHEETS.PLATFORMS, SMS.PLATFORM_HEADERS);
    ensureSheet_(ss, SMS.SHEETS.TEAM, SMS.TEAM_HEADERS);
    ensureSheet_(ss, SMS.SHEETS.ACTIVITY, SMS.ACTIVITY_HEADERS);
    ensureSheet_(ss, SMS.SHEETS.QUEUE, SMS.QUEUE_HEADERS);
    ensureSheet_(ss, SMS.SHEETS.REPORTS, SMS.REPORT_HEADERS);
    ensureSheet_(ss, SMS.SHEETS.CONFIG, SMS.CONFIG_HEADERS);
    seedSettings_(ss);
    applyValidationsAndFormatting_(ss);
    buildDashboardSheet_(ss);
    refreshCalendar_();
    installTriggers();
    return {ok: true, message: 'System setup/repair complete.', spreadsheetId: ss.getId()};
  });
}

function ensureSheet_(ss, name, headers) {
  let sh = ss.getSheetByName(name);
  if (!sh) sh = ss.insertSheet(name);
  if (headers.length) {
    if (sh.getMaxColumns() < headers.length) sh.insertColumnsAfter(sh.getMaxColumns(), headers.length - sh.getMaxColumns());
    const current = sh.getRange(1, 1, 1, headers.length).getDisplayValues()[0];
    if (current.join('|') !== headers.join('|')) sh.getRange(1, 1, 1, headers.length).setValues([headers]);
    styleHeader_(sh, headers.length);
    sh.setFrozenRows(1);
    if (!sh.getFilter() && sh.getMaxRows() > 1) sh.getRange(1, 1, Math.max(2, sh.getLastRow()), headers.length).createFilter();
  }
  return sh;
}

function styleHeader_(sh, count) {
  sh.getRange(1, 1, 1, count).setBackground('#14213d').setFontColor('#ffffff').setFontWeight('bold').setHorizontalAlignment('center').setWrap(true);
  sh.setRowHeight(1, 36);
}

function seedSettings_(ss) {
  const p = ss.getSheetByName(SMS.SHEETS.PLATFORMS);
  if (p.getLastRow() < 2) {
    const rows = [
      ['YouTube','Main Channel','Video,Live',true,'DIRECT','','60','3','Needs YouTube Advanced Service','Direct upload supported after authorization.'],
      ['YouTube Shorts','Main Channel','Short Video',true,'DIRECT','','60','3','Needs YouTube Advanced Service','Vertical media recommended.'],
      ['Instagram','Business Account','Image,Carousel',true,'MANUAL','https://www.instagram.com/','30','2','Not configured','Meta API adapter supports single image when token/account are configured.'],
      ['Instagram Reels','Business Account','Reel,Short Video',true,'MANUAL','https://www.instagram.com/','30','2','Not configured','Manual by default.'],
      ['Facebook Pages','Brand Page','Image,Video,Text,Link',true,'MANUAL','https://www.facebook.com/','30','2','Not configured','Graph API adapter supports text/link/image.'],
      ['TikTok','Brand Account','Short Video',true,'MANUAL','https://www.tiktok.com/','30','2','Not configured','TikTok Content Posting approval required.'],
      ['LinkedIn','Company Page','Text,Image,Video,Article,Link',true,'MANUAL','https://www.linkedin.com/','30','2','Not configured','Manual by default; LinkedIn app review required.'],
      ['X (Twitter)','Brand Account','Text,Image,Video,Link',true,'MANUAL','https://x.com/','15','2','Not configured','Manual by default; paid API tier/user OAuth may be required.']
    ];
    p.getRange(2, 1, rows.length, rows[0].length).setValues(rows);
  }
  const c = ss.getSheetByName(SMS.SHEETS.CONFIG);
  if (c.getLastRow() < 2) {
    const owner = Session.getEffectiveUser().getEmail() || '';
    const rows = [
      ['DEFAULT_TIME_ZONE', SMS.DEFAULT_TZ, 'New content ka default time zone', false],
      ['REMINDER_LEAD_MINUTES', '60', 'Publish se kitne minute pehle reminder', false],
      ['DAILY_SUMMARY_HOUR', '8', 'Local hour (0-23)', false],
      ['WEEKLY_REPORT_DAY', 'MONDAY', 'MONDAY-SUNDAY', false],
      ['NOTIFICATION_EMAILS', owner, 'Comma-separated recipients', false],
      ['CALENDAR_ID', 'primary', 'Google Calendar ID; primary allowed', false],
      ['CREATE_CALENDAR_EVENTS', 'TRUE', 'TRUE/FALSE', false],
      ['MAX_RETRIES_DEFAULT', '3', 'Maximum scheduler retries', false],
      ['RETRY_DELAY_MINUTES', '15', 'Backoff base delay', false],
      ['MAX_ITEMS_PER_RUN', '8', 'Execution quota safety cap', false],
      ['QUEUE_LOOKAHEAD_MINUTES', '1440', 'Queue refresh window', false],
      ['AUTO_PUBLISH_ENABLED', 'FALSE', 'Global kill switch; explicitly set TRUE', false],
      ['APPROVAL_REMINDER_HOURS', '24', 'Ready for Review notification interval', false]
    ];
    c.getRange(2, 1, rows.length, rows[0].length).setValues(rows);
  }
  const t = ss.getSheetByName(SMS.SHEETS.TEAM);
  if (t.getLastRow() < 2) t.appendRow([Session.getEffectiveUser().getEmail(), 'Owner', 'Admin', true, 'All', 'Email']);
}

function applyValidationsAndFormatting_(ss) {
  const sh = ss.getSheetByName(SMS.SHEETS.CONTENT);
  const rows = Math.max(1, sh.getMaxRows() - 1);
  setListValidation_(sh.getRange(2, 3, rows, 1), SMS.PLATFORMS);
  setListValidation_(sh.getRange(2, 4, rows, 1), SMS.CONTENT_TYPES);
  setListValidation_(sh.getRange(2, 9, rows, 1), SMS.CATEGORIES);
  setListValidation_(sh.getRange(2, 16, rows, 1), SMS.APPROVALS);
  setListValidation_(sh.getRange(2, 17, rows, 1), SMS.STATUSES);
  sh.getRange(2, 12, rows, 2).setNumberFormat('dd-mmm-yyyy');
  sh.getRange(2, 14, rows, 1).setNumberFormat('hh:mm');
  sh.getRange(2, 20, rows, 1).setNumberFormat('dd-mmm-yyyy hh:mm:ss');
  sh.setColumnWidths(1, 20, 125);
  sh.setColumnWidth(2, 220); sh.setColumnWidth(5, 320); sh.setColumnWidth(8, 260); sh.setColumnWidth(19, 260);
  const rules = [
    SpreadsheetApp.newConditionalFormatRule().whenTextEqualTo('Failed').setBackground('#fee2e2').setFontColor('#991b1b').setRanges([sh.getRange('Q2:Q')]).build(),
    SpreadsheetApp.newConditionalFormatRule().whenTextEqualTo('Published').setBackground('#dcfce7').setFontColor('#166534').setRanges([sh.getRange('Q2:Q')]).build(),
    SpreadsheetApp.newConditionalFormatRule().whenTextEqualTo('Ready for Review').setBackground('#fef3c7').setFontColor('#92400e').setRanges([sh.getRange('Q2:Q')]).build(),
    SpreadsheetApp.newConditionalFormatRule().whenFormulaSatisfied('=AND($M2<TODAY(),$Q2<>"Published",$Q2<>"Rejected")').setBackground('#fff1f2').setRanges([sh.getRange('A2:T')]).build()
  ];
  sh.setConditionalFormatRules(rules);
  const ps = ss.getSheetByName(SMS.SHEETS.PLATFORMS);
  setListValidation_(ps.getRange(2, 4, 100, 1), ['TRUE','FALSE']);
  setListValidation_(ps.getRange(2, 5, 100, 1), ['DIRECT','MANUAL']);
  const ts = ss.getSheetByName(SMS.SHEETS.TEAM);
  setListValidation_(ts.getRange(2, 3, 200, 1), ['Admin','Editor','Approver','Viewer']);
}

function setListValidation_(range, values) {
  range.setDataValidation(SpreadsheetApp.newDataValidation().requireValueInList(values, true).setAllowInvalid(false).build());
}

function buildDashboardSheet_(ss) {
  const sh = ss.getSheetByName(SMS.SHEETS.DASHBOARD);
  sh.clear(); sh.setHiddenGridlines(true);
  sh.getRange('A1:H1').merge().setValue('SOCIAL MEDIA COMMAND CENTER').setBackground('#14213d').setFontColor('#ffffff').setFontSize(20).setFontWeight('bold').setHorizontalAlignment('left');
  sh.setRowHeight(1, 54);
  const labels = [['Total Content','Ideas & Drafts','Pending Approval','Approved'],['Scheduled','Published','Failed','Overdue']];
  sh.getRange(3,1,2,4).setValues(labels).setBackground('#e8eef7').setFontWeight('bold').setHorizontalAlignment('center');
  sh.getRange('A6:D6').setValues([['Metric','Count','Metric','Count']]).setBackground('#14213d').setFontColor('#fff').setFontWeight('bold');
  sh.getRange('F3:H3').setValues([['Upcoming Date','Platform','Content']]).setBackground('#14213d').setFontColor('#fff').setFontWeight('bold');
  sh.setColumnWidth(1,160); sh.setColumnWidth(2,100); sh.setColumnWidth(3,180); sh.setColumnWidth(4,100); sh.setColumnWidth(6,150); sh.setColumnWidth(7,140); sh.setColumnWidth(8,260);
  refreshDashboardSheet_();
}

function refreshDashboardSheet_() {
  const ss = getSpreadsheet_(), sh = ss.getSheetByName(SMS.SHEETS.DASHBOARD), d = getDashboardData();
  const k = d.kpis;
  sh.getRange('A3:D4').setValues([
    [`Total Content\n${k.total}`, `Ideas & Drafts\n${k.drafts}`, `Pending Approval\n${k.pendingApproval}`, `Approved\n${k.approved}`],
    [`Scheduled\n${k.scheduled}`, `Published\n${k.published}`, `Failed\n${k.failed}`, `Overdue\n${k.overdue}`]
  ]).setWrap(true).setFontSize(12).setHorizontalAlignment('center').setVerticalAlignment('middle');
  sh.setRowHeights(3,2,58);
  const dist = d.platformDistribution.map(x => [x.platform,x.count]);
  const stat = d.weeklyStats.map(x => [x.label,x.count]);
  sh.getRange(7,1,Math.max(20,sh.getMaxRows()-6),4).clearContent();
  const max = Math.max(dist.length, stat.length, 1), rows=[];
  for (let i=0;i<max;i++) rows.push([dist[i] ? dist[i][0] : '',dist[i] ? dist[i][1] : '',stat[i] ? stat[i][0] : '',stat[i] ? stat[i][1] : '']);
  sh.getRange(7,1,rows.length,4).setValues(rows);
  sh.getRange(4,6,Math.max(20,sh.getMaxRows()-3),3).clearContent();
  if (d.upcoming.length) sh.getRange(4,6,d.upcoming.length,3).setValues(d.upcoming.map(x=>[x.scheduledAt,x.platform,x.title]));
}

function refreshSystemViews() { refreshCalendar_(); refreshDashboardSheet_(); return {ok:true}; }
function openDashboardSheet() { getSpreadsheet_().setActiveSheet(getSpreadsheet_().getSheetByName(SMS.SHEETS.DASHBOARD)); }

// SECTION 3: Web app / sidebar API and CRUD
function include(filename) { return HtmlService.createHtmlOutputFromFile(filename).getContent(); }

function doGet() {
  return HtmlService.createTemplateFromFile('index').evaluate()
    .setTitle('Social Media Scheduler')
    .setXFrameOptionsMode(HtmlService.XFrameOptionsMode.DEFAULT)
    .addMetaTag('viewport', 'width=device-width, initial-scale=1');
}

function showSidebar() {
  SpreadsheetApp.getUi().showSidebar(HtmlService.createTemplateFromFile('index').evaluate().setTitle('Social Scheduler').setWidth(420));
}

function getBootstrapData() {
  assertRole_(['Admin','Editor','Approver','Viewer']);
  return {
    version: SMS.VERSION,
    user: getCurrentUser_(),
    options: {platforms: SMS.PLATFORMS, contentTypes: SMS.CONTENT_TYPES, categories: SMS.CATEGORIES, statuses: SMS.STATUSES, approvals: SMS.APPROVALS, timeZones: ['Asia/Kolkata','UTC','America/New_York','America/Los_Angeles','Europe/London','Asia/Dubai','Asia/Singapore','Australia/Sydney']},
    settings: getPlatformSettings_(),
    dashboard: getDashboardData(),
    content: listContent({limit: 100})
  };
}

function listContent(filters) {
  assertRole_(['Admin','Editor','Approver','Viewer']);
  filters = filters || {};
  let items = getContentRecords_();
  const q = String(filters.query || '').trim().toLowerCase();
  if (q) items = items.filter(x => [x.contentId,x.contentTitle,x.caption,x.campaignName,x.assignedPerson,x.hashtags].join(' ').toLowerCase().includes(q));
  if (filters.platform && filters.platform !== 'All') items = items.filter(x => x.platform === filters.platform);
  if (filters.status && filters.status !== 'All') items = items.filter(x => x.publishingStatus === filters.status);
  if (filters.approval && filters.approval !== 'All') items = items.filter(x => x.approvalStatus === filters.approval);
  if (filters.from) items = items.filter(x => !x.scheduledDate || x.scheduledDate >= filters.from);
  if (filters.to) items = items.filter(x => !x.scheduledDate || x.scheduledDate <= filters.to);
  items.sort((a,b) => String(b.lastUpdated).localeCompare(String(a.lastUpdated)));
  const limit = Math.min(Number(filters.limit || 250), 1000);
  return items.slice(0, limit);
}

function getContent(contentId) {
  assertRole_(['Admin','Editor','Approver','Viewer']);
  const found = getContentRecords_().find(x => x.contentId === contentId);
  if (!found) throw new Error('Content record nahi mila: ' + contentId);
  found.activity = getActivity(contentId);
  return found;
}

function saveContent(input) {
  assertRole_(['Admin','Editor']);
  return withDocumentLock_(function () {
    const data = sanitizeContentInput_(input || {});
    validateContentInput_(data);
    const sh = getSpreadsheet_().getSheetByName(SMS.SHEETS.CONTENT);
    const records = getContentRecords_(true);
    const existing = data.contentId ? records.find(x => x.contentId === data.contentId) : null;
    if (data.contentId && !existing) throw new Error('Edit ke liye Content ID nahi mila.');
    checkDuplicateSchedule_(data, data.contentId || '');
    const now = new Date(), id = data.contentId || generateContentId_();
    const rowObject = Object.assign({}, existing || {}, data, {
      contentId: id,
      creationDate: existing ? existing.creationDate : formatDate_(now, 'yyyy-MM-dd'),
      timeZone: data.timeZone || getConfig_('DEFAULT_TIME_ZONE', SMS.DEFAULT_TZ),
      approvalStatus: existing ? (data.approvalStatus || existing.approvalStatus) : (data.approvalStatus || 'Not Submitted'),
      publishingStatus: existing ? (data.publishingStatus || existing.publishingStatus) : (data.publishingStatus || 'Idea'),
      lastUpdated: formatDate_(now, "yyyy-MM-dd'T'HH:mm:ss")
    });
    const values = objectToContentRow_(rowObject);
    if (existing) sh.getRange(existing._row, 1, 1, SMS.CONTENT_HEADERS.length).setValues([values]);
    else sh.appendRow(values);
    logActivity_(id, existing ? existing.publishingStatus : '', rowObject.publishingStatus, existing ? 'Content details updated' : 'Content created', 'UI');
    refreshCalendar_(); refreshDashboardSheet_();
    return getContent(id);
  });
}

function deleteContent(contentId) {
  assertRole_(['Admin']);
  return withDocumentLock_(function () {
    const sh = getSpreadsheet_().getSheetByName(SMS.SHEETS.CONTENT);
    const item = getContentRecords_(true).find(x => x.contentId === contentId);
    if (!item) throw new Error('Content record nahi mila.');
    if (['Publishing','Published'].includes(item.publishingStatus)) throw new Error('Publishing/Published record delete nahi ho sakta. Pehle pause ya archive policy use karein.');
    sh.deleteRow(item._row);
    logActivity_(contentId, item.publishingStatus, 'DELETED', 'Content deleted', 'UI');
    refreshCalendar_(); refreshDashboardSheet_();
    return {ok:true};
  });
}

function sanitizeContentInput_(x) {
  const clean = v => String(v == null ? '' : v).replace(/[\u0000-\u0008\u000B\u000C\u000E-\u001F]/g,'').trim();
  return {
    contentId: clean(x.contentId), contentTitle: clean(x.contentTitle), platform: clean(x.platform), contentType: clean(x.contentType),
    caption: clean(x.caption), hashtags: clean(x.hashtags), keywords: clean(x.keywords), mediaUrl: clean(x.mediaUrl),
    contentCategory: clean(x.contentCategory), campaignName: clean(x.campaignName), assignedPerson: clean(x.assignedPerson),
    scheduledDate: clean(x.scheduledDate), scheduledTime: clean(x.scheduledTime), timeZone: clean(x.timeZone),
    approvalStatus: clean(x.approvalStatus), publishingStatus: clean(x.publishingStatus), publishedUrl: clean(x.publishedUrl), errorMessage: clean(x.errorMessage)
  };
}

function validateContentInput_(d) {
  if (!d.contentTitle || d.contentTitle.length > 200) throw new Error('Content Title required hai aur 200 characters se chhota hona chahiye.');
  if (!SMS.PLATFORMS.includes(d.platform)) throw new Error('Valid Platform select karein.');
  if (!SMS.CONTENT_TYPES.includes(d.contentType)) throw new Error('Valid Content Type select karein.');
  if (d.mediaUrl && !/^https:\/\//i.test(d.mediaUrl)) throw new Error('Media URL HTTPS ya Google Drive link hona chahiye.');
  if (d.scheduledDate && !/^\d{4}-\d{2}-\d{2}$/.test(d.scheduledDate)) throw new Error('Scheduled Date format YYYY-MM-DD hona chahiye.');
  if (d.scheduledTime && !/^([01]\d|2[0-3]):[0-5]\d$/.test(d.scheduledTime)) throw new Error('Scheduled Time format HH:MM hona chahiye.');
  if ((d.scheduledDate && !d.scheduledTime) || (!d.scheduledDate && d.scheduledTime)) throw new Error('Scheduling ke liye date aur time dono required hain.');
  if (d.approvalStatus && !SMS.APPROVALS.includes(d.approvalStatus)) throw new Error('Invalid approval status.');
  if (d.publishingStatus && !SMS.STATUSES.includes(d.publishingStatus)) throw new Error('Invalid publishing status.');
}

function getContentRecords_(withRows) {
  const sh = getSpreadsheet_().getSheetByName(SMS.SHEETS.CONTENT);
  if (!sh || sh.getLastRow() < 2) return [];
  const values = sh.getRange(2,1,sh.getLastRow()-1,SMS.CONTENT_HEADERS.length).getValues();
  return values.filter(r => r[0]).map((r,i) => contentRowToObject_(r, withRows ? i+2 : null));
}

function contentRowToObject_(r, row) {
  const val = (v, pattern) => v instanceof Date ? formatDate_(v, pattern) : String(v == null ? '' : v);
  const o = {
    contentId:val(r[0]),contentTitle:val(r[1]),platform:val(r[2]),contentType:val(r[3]),caption:val(r[4]),hashtags:val(r[5]),keywords:val(r[6]),mediaUrl:val(r[7]),contentCategory:val(r[8]),campaignName:val(r[9]),assignedPerson:val(r[10]),
    creationDate:val(r[11],'yyyy-MM-dd'),scheduledDate:val(r[12],'yyyy-MM-dd'),scheduledTime:val(r[13],'HH:mm'),timeZone:val(r[14]),approvalStatus:val(r[15]),publishingStatus:val(r[16]),publishedUrl:val(r[17]),errorMessage:val(r[18]),lastUpdated:val(r[19],"yyyy-MM-dd'T'HH:mm:ss")
  };
  if (row) o._row = row;
  o.scheduledAt = o.scheduledDate && o.scheduledTime ? o.scheduledDate + 'T' + o.scheduledTime : '';
  return o;
}

function objectToContentRow_(o) {
  return [o.contentId,o.contentTitle,o.platform,o.contentType,o.caption,o.hashtags,o.keywords,o.mediaUrl,o.contentCategory,o.campaignName,o.assignedPerson,
    parseDateCell_(o.creationDate),parseDateCell_(o.scheduledDate),parseTimeCell_(o.scheduledTime),o.timeZone,o.approvalStatus,o.publishingStatus,o.publishedUrl,o.errorMessage,new Date()];
}

function checkDuplicateSchedule_(d, excludeId) {
  if (!d.scheduledDate || !d.scheduledTime) return;
  const duplicate = getContentRecords_().find(x => x.contentId !== excludeId && x.platform === d.platform && x.scheduledDate === d.scheduledDate && x.scheduledTime === d.scheduledTime && !['Rejected','Paused','Failed'].includes(x.publishingStatus));
  if (duplicate) throw new Error(`Duplicate slot: ${duplicate.contentId} same platform/date/time par scheduled hai.`);
}

// SECTION 4: Workflow and activity log
function updateStatus(contentId, newStatus, comment) {
  const user = getCurrentUser_();
  if (['Approved','Revision Required','Rejected'].includes(newStatus)) assertRole_(['Admin','Approver']);
  else assertRole_(['Admin','Editor','Approver']);
  return withDocumentLock_(function () {
    if (!SMS.STATUSES.includes(newStatus)) throw new Error('Unknown workflow status.');
    const sh = getSpreadsheet_().getSheetByName(SMS.SHEETS.CONTENT);
    const item = getContentRecords_(true).find(x => x.contentId === contentId);
    if (!item) throw new Error('Content record nahi mila.');
    const allowed = SMS.TRANSITIONS[item.publishingStatus] || [];
    if (!allowed.includes(newStatus)) throw new Error(`Invalid transition: ${item.publishingStatus} → ${newStatus}. Allowed: ${allowed.join(', ') || 'none'}`);
    if (newStatus === 'Scheduled') {
      if (item.approvalStatus !== 'Approved') throw new Error('Sirf Approved content schedule ho sakta hai.');
      if (!item.scheduledDate || !item.scheduledTime) throw new Error('Scheduled Date aur Time required hain.');
      checkDuplicateSchedule_(item, item.contentId);
    }
    if (newStatus === 'Publishing' && item.approvalStatus !== 'Approved') throw new Error('Approval ke bina publishing blocked hai.');
    let approval = item.approvalStatus;
    if (newStatus === 'Ready for Review') approval = 'Pending';
    if (newStatus === 'Approved') approval = 'Approved';
    if (newStatus === 'Revision Required') approval = 'Revision Required';
    if (newStatus === 'Rejected') approval = 'Rejected';
    sh.getRange(item._row, 16).setValue(approval);
    sh.getRange(item._row, 17).setValue(newStatus);
    sh.getRange(item._row, 20).setValue(new Date());
    logActivity_(contentId, item.publishingStatus, newStatus, String(comment || 'Status updated by ' + user.email), 'UI');
    if (newStatus === 'Ready for Review') notifyApprovalPending_(Object.assign({}, item,{approvalStatus:approval,publishingStatus:newStatus}));
    if (newStatus === 'Scheduled') { upsertQueueItem_(Object.assign({}, item,{approvalStatus:approval,publishingStatus:newStatus})); createCalendarEvent_(item); }
    refreshCalendar_(); refreshDashboardSheet_();
    return getContent(contentId);
  });
}

function approveContent(contentId, comment) { return updateStatus(contentId, 'Approved', comment || 'Approved'); }
function requestRevision(contentId, comment) {
  if (!String(comment || '').trim()) throw new Error('Revision request ke saath comment required hai.');
  return updateStatus(contentId, 'Revision Required', comment);
}

function getActivity(contentId) {
  assertRole_(['Admin','Editor','Approver','Viewer']);
  const sh = getSpreadsheet_().getSheetByName(SMS.SHEETS.ACTIVITY);
  if (sh.getLastRow() < 2) return [];
  return sh.getRange(2,1,sh.getLastRow()-1,SMS.ACTIVITY_HEADERS.length).getValues()
    .filter(r => !contentId || String(r[2]) === String(contentId))
    .map(r => ({timestamp:formatAnyDate_(r[0]),logId:String(r[1]),contentId:String(r[2]),previousStatus:String(r[3]),newStatus:String(r[4]),comment:String(r[5]),changedBy:String(r[6]),source:String(r[7])}))
    .sort((a,b)=>b.timestamp.localeCompare(a.timestamp)).slice(0,500);
}

function logActivity_(contentId, previousStatus, newStatus, comment, source) {
  getSpreadsheet_().getSheetByName(SMS.SHEETS.ACTIVITY).appendRow([
    new Date(), 'LOG-' + Utilities.getUuid().slice(0,8).toUpperCase(), contentId, previousStatus || '', newStatus || '', comment || '', getCurrentUser_().email, source || 'SYSTEM'
  ]);
}

function onEdit(e) {
  if (!e || !e.range) return;
  const sh = e.range.getSheet();
  if (sh.getName() !== SMS.SHEETS.CONTENT || e.range.getRow() < 2) return;
  const row = e.range.getRow(), col = e.range.getColumn();
  try {
    if (!sh.getRange(row,1).getValue()) sh.getRange(row,1).setValue(generateContentId_());
    sh.getRange(row,20).setValue(new Date());
    if (col === 17 && e.oldValue && e.value && e.oldValue !== e.value) {
      const allowed = SMS.TRANSITIONS[e.oldValue] || [];
      if (!allowed.includes(e.value)) {
        e.range.setValue(e.oldValue);
        SpreadsheetApp.getActive().toast(`Invalid transition: ${e.oldValue} → ${e.value}`, 'Workflow blocked', 6);
        return;
      }
      const id = String(sh.getRange(row,1).getValue());
      const approval = String(sh.getRange(row,16).getValue());
      if (['Scheduled','Publishing'].includes(e.value) && approval !== 'Approved') {
        e.range.setValue(e.oldValue);
        SpreadsheetApp.getActive().toast('Approval required before scheduling/publishing.', 'Workflow blocked', 6);
        return;
      }
      if (e.value === 'Ready for Review') sh.getRange(row,16).setValue('Pending');
      if (e.value === 'Approved') sh.getRange(row,16).setValue('Approved');
      if (e.value === 'Revision Required') sh.getRange(row,16).setValue('Revision Required');
      if (e.value === 'Rejected') sh.getRange(row,16).setValue('Rejected');
      logActivity_(id,e.oldValue,e.value,'Status edited directly in sheet','SHEET');
    }
  } catch (err) {
    console.error(err);
  }
}

// SECTION 5: Calendar, queue, scheduler, and notifications
function getCalendarData(view, anchorDate) {
  assertRole_(['Admin','Editor','Approver','Viewer']);
  const anchor = anchorDate ? new Date(anchorDate + 'T12:00:00') : new Date();
  let start = new Date(anchor), end = new Date(anchor);
  if (view === 'day') { start.setHours(0,0,0,0); end.setHours(23,59,59,999); }
  else if (view === 'week') {
    const day = (start.getDay()+6)%7; start.setDate(start.getDate()-day); start.setHours(0,0,0,0);
    end = new Date(start); end.setDate(end.getDate()+6); end.setHours(23,59,59,999);
  } else {
    start = new Date(anchor.getFullYear(),anchor.getMonth(),1); end = new Date(anchor.getFullYear(),anchor.getMonth()+1,0,23,59,59,999);
  }
  return getContentRecords_().filter(x=>x.scheduledAt).map(x=>Object.assign({},x,{_date:scheduledDate_(x)})).filter(x=>x._date>=start&&x._date<=end)
    .sort((a,b)=>a._date-b._date).map(x=>{delete x._date;return x;});
}

function refreshCalendar_() {
  const ss = getSpreadsheet_(), sh = ss.getSheetByName(SMS.SHEETS.CALENDAR);
  if (!sh) return;
  if (sh.getLastRow()>1) sh.getRange(2,1,sh.getLastRow()-1,SMS.CAL_HEADERS.length).clearContent();
  const settings = getPlatformSettings_().reduce((m,x)=>(m[x.platform]=x,m),{});
  const rows = getContentRecords_().filter(x=>x.scheduledAt).sort((a,b)=>scheduledDate_(a)-scheduledDate_(b)).map(x=>[
    scheduledDate_(x),x.contentId,x.contentTitle,x.platform,(settings[x.platform]||{}).accountName||'',x.contentType,x.approvalStatus,x.publishingStatus,x.assignedPerson,
    x.publishingStatus==='Published'?'Published':((settings[x.platform]||{}).publishingMode==='DIRECT'?'Automatic/Direct':'Manual checklist')
  ]);
  if (rows.length) sh.getRange(2,1,rows.length,rows[0].length).setValues(rows);
  sh.getRange('A2:A').setNumberFormat('dd-mmm-yyyy hh:mm');
  sh.setColumnWidths(1,SMS.CAL_HEADERS.length,140); sh.setColumnWidth(3,260);
}

function installTriggers() {
  assertRole_(['Admin']);
  const wanted = ['runScheduler','sendDailySummary','sendWeeklyReport'];
  ScriptApp.getProjectTriggers().forEach(t=>{ if (wanted.includes(t.getHandlerFunction())) ScriptApp.deleteTrigger(t); });
  ScriptApp.newTrigger('runScheduler').timeBased().everyMinutes(5).create();
  ScriptApp.newTrigger('sendDailySummary').timeBased().atHour(Number(getConfig_('DAILY_SUMMARY_HOUR','8'))).everyDays(1).create();
  ScriptApp.newTrigger('sendWeeklyReport').timeBased().onWeekDay(ScriptApp.WeekDay.MONDAY).atHour(9).create();
  return {ok:true,message:'Unique scheduler, daily summary, and weekly report triggers installed.'};
}

function runScheduler() {
  return withDocumentLock_(function () {
    refreshPublishingQueue_();
    sendUpcomingReminders_();
    const sh = getSpreadsheet_().getSheetByName(SMS.SHEETS.QUEUE);
    if (sh.getLastRow()<2) return {ok:true,processed:0};
    const rows = sh.getRange(2,1,sh.getLastRow()-1,SMS.QUEUE_HEADERS.length).getValues();
    let processed=0;
    const maxPerRun=Math.max(1,Number(getConfig_('MAX_ITEMS_PER_RUN','8'))||8);
    rows.forEach((r,i)=>{
      const status=String(r[5]), scheduled=r[2] instanceof Date?r[2]:new Date(r[2]), next=r[9] instanceof Date?r[9]:(r[9]?new Date(r[9]):scheduled);
      if (processed<maxPerRun&&['QUEUED','RETRY'].includes(status) && scheduled<=new Date() && next<=new Date()) { processQueueItem_(r,i+2); processed++; }
    });
    refreshCalendar_(); refreshDashboardSheet_();
    return {ok:true,processed:processed};
  });
}

function refreshPublishingQueue_() {
  getContentRecords_().filter(x=>x.publishingStatus==='Scheduled'&&x.approvalStatus==='Approved'&&x.scheduledAt).forEach(upsertQueueItem_);
}

function upsertQueueItem_(item) {
  const ss=getSpreadsheet_(), sh=ss.getSheetByName(SMS.SHEETS.QUEUE), existing=getQueueRecords_().find(x=>x.contentId===item.contentId&&!['SUCCESS','CANCELLED'].includes(x.queueStatus));
  const setting=getPlatformSettings_().find(x=>x.platform===item.platform)||{};
  const max=Number(setting.maximumRetries||getConfig_('MAX_RETRIES_DEFAULT','3'));
  const mode=(String(getConfig_('AUTO_PUBLISH_ENABLED','FALSE')).toUpperCase()==='TRUE'&&setting.publishingMode==='DIRECT')?'DIRECT':'MANUAL';
  const scheduled=scheduledDate_(item), reset=existing&&(existing.queueStatus==='FAILED'||Number(existing.scheduledAt)!==scheduled.getTime());
  const row=[existing?existing.queueId:'Q-'+Utilities.getUuid().slice(0,8).toUpperCase(),item.contentId,scheduled,item.platform,mode,existing&&!reset?existing.queueStatus:'QUEUED',existing&&!reset?existing.attempts:0,max,existing&&!reset?existing.lastAttempt:'',existing&&!reset?existing.nextAttempt:scheduled,existing&&!reset?existing.resultUrl:'',existing&&!reset?existing.errorMessage:'',new Date()];
  if(existing) sh.getRange(existing._row,1,1,row.length).setValues([row]); else sh.appendRow(row);
}

function processQueueItem_(r,rowNumber) {
  const sh=getSpreadsheet_().getSheetByName(SMS.SHEETS.QUEUE), contentId=String(r[1]), mode=String(r[4]), attempts=Number(r[6]||0)+1, max=Number(r[7]||3);
  const item=getContentRecords_(true).find(x=>x.contentId===contentId);
  if(!item){updateQueueRow_(rowNumber,{status:'CANCELLED',attempts:attempts,error:'Content missing'});return;}
  if(item.approvalStatus!=='Approved'||item.publishingStatus!=='Scheduled'){updateQueueRow_(rowNumber,{status:'CANCELLED',attempts:attempts,error:'Approval/status changed'});return;}
  if(mode==='MANUAL') {
    const setting=getPlatformSettings_().find(x=>x.platform===item.platform)||{};
    sendEmail_('Manual publish due: '+item.contentTitle,manualChecklistHtml_(item,setting));
    updateQueueRow_(rowNumber,{status:'MANUAL_DUE',attempts:attempts,error:'Direct API publishing is not enabled/configured.'});
    logActivity_(contentId,'Scheduled','Scheduled','Manual publishing reminder sent; success not claimed.','SCHEDULER');
    return;
  }
  setContentStatusInternal_(item,'Publishing','Scheduler started official API publishing.');
  try {
    const result=publishViaOfficialApi_(item);
    if(!result||!result.success||!result.url) throw new Error('Official API did not return a confirmed published URL/ID.');
    setContentPublished_(item,result.url);
    updateQueueRow_(rowNumber,{status:'SUCCESS',attempts:attempts,url:result.url,error:''});
  } catch(err) {
    const message=truncate_(err && err.message ? err.message : String(err),500);
    const exhausted=attempts>=max;
    setContentFailed_(item,message,exhausted);
    updateQueueRow_(rowNumber,{status:exhausted?'FAILED':'RETRY',attempts:attempts,error:message,next:exhausted?'':new Date(Date.now()+Number(getConfig_('RETRY_DELAY_MINUTES','15'))*60000*Math.pow(2,attempts-1))});
    sendEmail_('Publishing failed: '+item.contentTitle,`<p><b>${escapeHtml_(item.contentId)}</b> on ${escapeHtml_(item.platform)}</p><p>${escapeHtml_(message)}</p><p>Attempt ${attempts}/${max}; ${exhausted?'manual action required':'automatic retry queued'}.</p>`);
  }
}

function updateQueueRow_(row,o) {
  const sh=getSpreadsheet_().getSheetByName(SMS.SHEETS.QUEUE);
  sh.getRange(row,6).setValue(o.status); sh.getRange(row,7).setValue(o.attempts); sh.getRange(row,9).setValue(new Date());
  if(Object.prototype.hasOwnProperty.call(o,'next')) sh.getRange(row,10).setValue(o.next);
  if(Object.prototype.hasOwnProperty.call(o,'url')) sh.getRange(row,11).setValue(o.url);
  sh.getRange(row,12).setValue(o.error||''); sh.getRange(row,13).setValue(new Date());
}

function getQueueRecords_() {
  const sh=getSpreadsheet_().getSheetByName(SMS.SHEETS.QUEUE); if(sh.getLastRow()<2)return[];
  return sh.getRange(2,1,sh.getLastRow()-1,SMS.QUEUE_HEADERS.length).getValues().filter(r=>r[0]).map((r,i)=>({queueId:String(r[0]),contentId:String(r[1]),scheduledAt:r[2],platform:String(r[3]),mode:String(r[4]),queueStatus:String(r[5]),attempts:Number(r[6]),maxAttempts:Number(r[7]),lastAttempt:r[8],nextAttempt:r[9],resultUrl:String(r[10]),errorMessage:String(r[11]),_row:i+2}));
}

function setContentStatusInternal_(item,status,comment) {
  const sh=getSpreadsheet_().getSheetByName(SMS.SHEETS.CONTENT); sh.getRange(item._row,17).setValue(status); sh.getRange(item._row,20).setValue(new Date());
  logActivity_(item.contentId,item.publishingStatus,status,comment,'SCHEDULER'); item.publishingStatus=status;
}

function setContentPublished_(item,url) {
  const sh=getSpreadsheet_().getSheetByName(SMS.SHEETS.CONTENT); sh.getRange(item._row,17,1,4).setValues([['Published',url,'',new Date()]]);
  logActivity_(item.contentId,'Publishing','Published','Official API confirmed publishing.','SCHEDULER');
}

function setContentFailed_(item,error,exhausted) {
  const sh=getSpreadsheet_().getSheetByName(SMS.SHEETS.CONTENT); sh.getRange(item._row,17).setValue(exhausted?'Failed':'Scheduled'); sh.getRange(item._row,19,1,2).setValues([[error,new Date()]]);
  logActivity_(item.contentId,'Publishing',exhausted?'Failed':'Scheduled',error,'SCHEDULER');
}

function sendUpcomingReminders_() {
  const now=Date.now(), props=PropertiesService.getScriptProperties(), settings=getPlatformSettings_().reduce((m,x)=>(m[x.platform]=x,m),{});
  getContentRecords_().filter(x=>x.publishingStatus==='Scheduled'&&x.scheduledAt).forEach(item=>{
    const lead=Number((settings[item.platform]||{}).reminderLeadMinutes||getConfig_('REMINDER_LEAD_MINUTES','60')), diff=scheduledDate_(item).getTime()-now, key='REMINDER_'+item.contentId+'_'+item.scheduledAt;
    if(diff>0&&diff<=lead*60000&&!props.getProperty(key)){
      sendEmail_('Upcoming post: '+item.contentTitle,manualChecklistHtml_(item,settings[item.platform]||{})); props.setProperty(key,new Date().toISOString());
    }
  });
}

function notifyApprovalPending_(item) {
  sendEmail_('Approval pending: '+item.contentTitle,`<h2>Content approval required</h2><p><b>${escapeHtml_(item.contentId)}</b> — ${escapeHtml_(item.contentTitle)}</p><p>Platform: ${escapeHtml_(item.platform)}</p><p>Open the Sheet sidebar/web app to approve or request revision.</p>`);
}

function sendDailySummary() {
  const today=formatDate_(new Date(),'yyyy-MM-dd'), items=getContentRecords_().filter(x=>x.scheduledDate===today);
  const rows=items.map(x=>`<li>${escapeHtml_(x.scheduledTime)} · ${escapeHtml_(x.platform)} · ${escapeHtml_(x.contentTitle)} · ${escapeHtml_(x.publishingStatus)}</li>`).join('');
  sendEmail_('Daily social schedule — '+today,`<h2>Daily scheduled content</h2>${rows?'<ul>'+rows+'</ul>':'<p>No content scheduled.</p>'}`);
  return {ok:true,count:items.length};
}

function sendWeeklyReport() {
  const data=getDashboardData(), sh=getSpreadsheet_().getSheetByName(SMS.SHEETS.REPORTS), stamp=new Date();
  Object.keys(data.kpis).forEach(k=>sh.appendRow([stamp,'Weekly',k,'All',data.kpis[k],'Automated snapshot']));
  sendEmail_('Weekly social workflow report',`<h2>Weekly workflow report</h2><p>Total: ${data.kpis.total} | Published: ${data.kpis.published} | Scheduled: ${data.kpis.scheduled} | Failed: ${data.kpis.failed} | Overdue: ${data.kpis.overdue}</p>`);
  return {ok:true};
}

function createCalendarEvent_(item) {
  if(String(getConfig_('CREATE_CALENDAR_EVENTS','TRUE')).toUpperCase()!=='TRUE')return;
  try{
    const start=scheduledDate_(item),end=new Date(start.getTime()+30*60000),calendarId=getConfig_('CALENDAR_ID','primary'),cal=calendarId==='primary'?CalendarApp.getDefaultCalendar():CalendarApp.getCalendarById(calendarId);
    if(!cal)return;
    const title=`[${item.platform}] ${item.contentTitle} (${item.contentId})`;
    if(!cal.getEvents(start,end,{search:item.contentId}).length) cal.createEvent(title,start,end,{description:`Status: ${item.publishingStatus}\nMedia: ${item.mediaUrl||'n/a'}\nCaption: ${item.caption||''}`});
  }catch(err){console.warn('Calendar event skipped: '+err.message);}
}

function manualChecklistHtml_(item,setting) {
  const link=setting.platformOpeningUrl?`<p><a href="${escapeHtml_(setting.platformOpeningUrl)}">Open ${escapeHtml_(item.platform)}</a></p>`:'';
  return `<h2>Manual publishing checklist</h2><p><b>${escapeHtml_(item.contentTitle)}</b> (${escapeHtml_(item.contentId)})</p><ol><li>Open platform/account: ${escapeHtml_(setting.accountName||'configured account')}</li><li>Verify media: ${escapeHtml_(item.mediaUrl||'not supplied')}</li><li>Copy caption and hashtags.</li><li>Publish manually.</li><li>In scheduler, add Published URL and move status to Published only after verification.</li></ol>${link}<pre>${escapeHtml_((item.caption||'')+'\n'+(item.hashtags||''))}</pre>`;
}

function sendEmail_(subject,html) {
  const recipients=String(getConfig_('NOTIFICATION_EMAILS','')).split(',').map(x=>x.trim()).filter(Boolean);
  if(!recipients.length||MailApp.getRemainingDailyQuota()<recipients.length){console.warn('Email skipped: recipients/quota unavailable');return false;}
  MailApp.sendEmail({to:recipients.join(','),subject:'[Social Scheduler] '+subject,htmlBody:html,body:stripHtml_(html),name:'Social Media Scheduler'}); return true;
}

// SECTION 6: Official publishing adapters and truthful manual fallback
function publishViaOfficialApi_(item) {
  switch(item.platform){
    case 'YouTube': case 'YouTube Shorts': return publishYouTube_(item);
    case 'Instagram': case 'Instagram Reels': return publishInstagram_(item);
    case 'Facebook Pages': return publishFacebook_(item);
    default: throw new Error(`${item.platform} direct adapter enabled nahi hai. Publishing success claim nahi ki gayi; MANUAL mode use karein.`);
  }
}

function publishYouTube_(item) {
  const fileId=extractDriveFileId_(item.mediaUrl); if(!fileId)throw new Error('YouTube direct upload ke liye Media URL mein accessible Google Drive file link/ID required hai.');
  const file=DriveApp.getFileById(fileId), blob=file.getBlob(), privacy=PropertiesService.getScriptProperties().getProperty('YOUTUBE_PRIVACY_STATUS')||'private';
  const resource={snippet:{title:item.contentTitle,description:[item.caption,item.hashtags].filter(Boolean).join('\n\n'),tags:String(item.keywords||'').split(',').map(x=>x.trim()).filter(Boolean),categoryId:PropertiesService.getScriptProperties().getProperty('YOUTUBE_CATEGORY_ID')||'22'},status:{privacyStatus:privacy,selfDeclaredMadeForKids:false}};
  const response=YouTube.Videos.insert(resource,'snippet,status',blob);
  if(!response||!response.id)throw new Error('YouTube API response mein video ID nahi mila.');
  return {success:true,url:'https://www.youtube.com/watch?v='+encodeURIComponent(response.id),id:response.id};
}

function publishInstagram_(item) {
  const props=PropertiesService.getScriptProperties(),token=props.getProperty('META_ACCESS_TOKEN'),userId=props.getProperty('META_IG_USER_ID'),version=props.getProperty('META_GRAPH_VERSION');
  if(!token||!userId||!version)throw new Error('META_ACCESS_TOKEN, META_IG_USER_ID, aur META_GRAPH_VERSION Script Properties mein required hain.');
  if(!/^https:\/\//i.test(item.mediaUrl)||/drive\.google\.com/i.test(item.mediaUrl))throw new Error('Instagram API ko publicly accessible HTTPS media URL required hai; normal Drive share link supported nahi hai.');
  const base='https://graph.facebook.com/'+encodeURIComponent(version), isReel=item.platform==='Instagram Reels';
  const createPayload=isReel?{media_type:'REELS',video_url:item.mediaUrl,caption:[item.caption,item.hashtags].filter(Boolean).join('\n')}:{image_url:item.mediaUrl,caption:[item.caption,item.hashtags].filter(Boolean).join('\n')};
  const container=metaRequest_(base+'/'+encodeURIComponent(userId)+'/media','post',createPayload,token);
  if(!container.id)throw new Error('Instagram media container ID missing.');
  if(isReel)waitForIgContainer_(base,container.id,token);
  const published=metaRequest_(base+'/'+encodeURIComponent(userId)+'/media_publish','post',{creation_id:container.id},token);
  if(!published.id)throw new Error('Instagram publish ID missing.');
  const info=metaRequest_(base+'/'+encodeURIComponent(published.id),'get',{fields:'permalink'},token);
  if(!info.permalink)throw new Error('Instagram published permalink confirm nahi hua.');
  return {success:true,url:info.permalink,id:published.id};
}

function waitForIgContainer_(base,id,token) {
  for(let i=0;i<10;i++){
    const state=metaRequest_(base+'/'+encodeURIComponent(id),'get',{fields:'status_code'},token);
    if(state.status_code==='FINISHED')return;
    if(state.status_code==='ERROR'||state.status_code==='EXPIRED')throw new Error('Instagram container status: '+state.status_code);
    Utilities.sleep(5000);
  }
  throw new Error('Instagram container processing timeout; scheduler retry karega.');
}

function publishFacebook_(item) {
  const props=PropertiesService.getScriptProperties(),token=props.getProperty('META_ACCESS_TOKEN'),pageId=props.getProperty('META_FB_PAGE_ID'),version=props.getProperty('META_GRAPH_VERSION');
  if(!token||!pageId||!version)throw new Error('META_ACCESS_TOKEN, META_FB_PAGE_ID, aur META_GRAPH_VERSION Script Properties mein required hain.');
  const base='https://graph.facebook.com/'+encodeURIComponent(version),message=[item.caption,item.hashtags].filter(Boolean).join('\n'), isImage=item.contentType==='Image'&&item.mediaUrl;
  if(['Video','Reel','Short Video'].includes(item.contentType))throw new Error('Facebook video adapter is build mein enabled nahi hai; Platform Settings ko MANUAL karein.');
  const response=metaRequest_(base+'/'+encodeURIComponent(pageId)+(isImage?'/photos':'/feed'),'post',isImage?{url:item.mediaUrl,caption:message}:{message:message,link:item.mediaUrl||''},token);
  const postId=response.post_id||response.id; if(!postId)throw new Error('Facebook API response mein post ID missing.');
  const info=metaRequest_(base+'/'+encodeURIComponent(postId),'get',{fields:'permalink_url'},token);
  if(!info.permalink_url)throw new Error('Facebook permalink confirm nahi hua.');
  return {success:true,url:info.permalink_url,id:postId};
}

function metaRequest_(url,method,payload,token) {
  const options={method:method,muteHttpExceptions:true,headers:{Authorization:'Bearer '+token}};
  if(method.toLowerCase()==='get'){
    const qs=Object.keys(payload||{}).map(k=>encodeURIComponent(k)+'='+encodeURIComponent(payload[k])).join('&'); if(qs)url+='?'+qs;
  }else options.payload=payload;
  const res=UrlFetchApp.fetch(url,options),code=res.getResponseCode(),text=res.getContentText();
  let json={};try{json=JSON.parse(text);}catch(ignore){}
  if(code<200||code>=300||json.error)throw new Error('Meta API '+code+': '+truncate_((json.error&&json.error.message)||text,350));
  return json;
}

function confirmManualPublished(contentId,publishedUrl,comment) {
  assertRole_(['Admin','Editor']);
  if(!/^https:\/\//i.test(String(publishedUrl||'')))throw new Error('Verified HTTPS Published URL required hai.');
  return withDocumentLock_(function(){
    const item=getContentRecords_(true).find(x=>x.contentId===contentId); if(!item)throw new Error('Content record nahi mila.');
    if(!['Scheduled','Publishing','Failed'].includes(item.publishingStatus))throw new Error('Manual confirmation Scheduled, Publishing, ya Failed item ke liye allowed hai.');
    const sh=getSpreadsheet_().getSheetByName(SMS.SHEETS.CONTENT); sh.getRange(item._row,17,1,4).setValues([['Published',publishedUrl,'',new Date()]]);
    logActivity_(contentId,item.publishingStatus,'Published',comment||'Manual publishing verified with URL.','UI');
    const q=getQueueRecords_().find(x=>x.contentId===contentId&&!['SUCCESS','CANCELLED'].includes(x.queueStatus)); if(q)updateQueueRow_(q._row,{status:'SUCCESS',attempts:q.attempts,url:publishedUrl,error:''});
    refreshSystemViews(); return getContent(contentId);
  });
}

// SECTION 7: Reports, CSV export, utilities, and sample data
function getDashboardData() {
  const items=getContentRecords_(),now=new Date(),draftStates=['Idea','Content Planning','In Production','Revision Required'];
  const kpis={total:items.length,drafts:items.filter(x=>draftStates.includes(x.publishingStatus)).length,pendingApproval:items.filter(x=>x.approvalStatus==='Pending'||x.publishingStatus==='Ready for Review').length,approved:items.filter(x=>x.approvalStatus==='Approved').length,scheduled:items.filter(x=>x.publishingStatus==='Scheduled').length,published:items.filter(x=>x.publishingStatus==='Published').length,failed:items.filter(x=>x.publishingStatus==='Failed').length,overdue:items.filter(x=>x.scheduledAt&&scheduledDate_(x)<now&&!['Published','Rejected','Paused'].includes(x.publishingStatus)).length};
  const platformDistribution=SMS.PLATFORMS.map(p=>({platform:p,count:items.filter(x=>x.platform===p).length})).filter(x=>x.count);
  const weeklyStats=[],monthlyStats=[],publishedDates=getPublishedDates_();
  for(let i=7;i>=0;i--){const start=startOfWeek_(new Date(Date.now()-i*7*86400000)),end=new Date(start.getTime()+7*86400000);weeklyStats.push({label:formatDate_(start,'dd MMM'),count:publishedDates.filter(d=>d>=start&&d<end).length});}
  for(let i=5;i>=0;i--){const d=new Date();d.setDate(1);d.setMonth(d.getMonth()-i);d.setHours(0,0,0,0);const end=new Date(d.getFullYear(),d.getMonth()+1,1);monthlyStats.push({label:formatDate_(d,'MMM yyyy'),count:publishedDates.filter(x=>x>=d&&x<end).length});}
  const upcoming=items.filter(x=>x.scheduledAt&&scheduledDate_(x)>=now&&x.publishingStatus==='Scheduled').sort((a,b)=>scheduledDate_(a)-scheduledDate_(b)).slice(0,12).map(x=>({contentId:x.contentId,title:x.contentTitle,platform:x.platform,scheduledAt:formatDate_(scheduledDate_(x),'dd MMM, HH:mm'),status:x.publishingStatus}));
  return {kpis:kpis,platformDistribution:platformDistribution,weeklyStats:weeklyStats,monthlyStats:monthlyStats,upcoming:upcoming};
}

function exportContentCsv(filters) {
  assertRole_(['Admin','Editor','Approver','Viewer']);
  const rows=[SMS.CONTENT_HEADERS].concat(listContent(filters||{}).map(objectToContentExportRow_));
  return rows.map(r=>r.map(csvEscape_).join(',')).join('\r\n');
}

function getPublishedDates_(){const sh=getSpreadsheet_().getSheetByName(SMS.SHEETS.ACTIVITY);if(!sh||sh.getLastRow()<2)return[];return sh.getRange(2,1,sh.getLastRow()-1,5).getValues().filter(r=>String(r[4])==='Published'&&r[0] instanceof Date).map(r=>r[0]);}

function objectToContentExportRow_(o){return [o.contentId,o.contentTitle,o.platform,o.contentType,o.caption,o.hashtags,o.keywords,o.mediaUrl,o.contentCategory,o.campaignName,o.assignedPerson,o.creationDate,o.scheduledDate,o.scheduledTime,o.timeZone,o.approvalStatus,o.publishingStatus,o.publishedUrl,o.errorMessage,o.lastUpdated];}

function loadSampleData() {
  assertRole_(['Admin']);
  const existing=getContentRecords_(); if(existing.some(x=>/^Sample:/.test(x.contentTitle)))return {ok:false,message:'Sample data already exists.'};
  const tomorrow=new Date(Date.now()+86400000),date=formatDate_(tomorrow,'yyyy-MM-dd');
  [
    {contentTitle:'Sample: Product tip carousel',platform:'Instagram',contentType:'Carousel',caption:'Three practical ways to use our product.',hashtags:'#ProductTips #HowTo',keywords:'tips,product',contentCategory:'Educational',campaignName:'Onboarding',assignedPerson:'Content Team',scheduledDate:date,scheduledTime:'11:00',timeZone:SMS.DEFAULT_TZ,publishingStatus:'Idea'},
    {contentTitle:'Sample: Weekly insight',platform:'LinkedIn',contentType:'Text',caption:'A useful weekly industry insight.',hashtags:'#Industry #Leadership',keywords:'industry,insight',contentCategory:'Thought Leadership',campaignName:'Authority',assignedPerson:'Founder',scheduledDate:date,scheduledTime:'16:00',timeZone:SMS.DEFAULT_TZ,publishingStatus:'Content Planning'},
    {contentTitle:'Sample: Tutorial short',platform:'YouTube Shorts',contentType:'Short Video',caption:'Fast tutorial in under 60 seconds.',hashtags:'#Shorts #Tutorial',keywords:'tutorial,short',contentCategory:'Educational',campaignName:'Learn',assignedPerson:'Video Team',scheduledDate:date,scheduledTime:'18:00',timeZone:SMS.DEFAULT_TZ,publishingStatus:'In Production'}
  ].forEach(saveContent);
  return {ok:true,message:'3 sample records added.'};
}

function getPlatformSettings_(){const sh=getSpreadsheet_().getSheetByName(SMS.SHEETS.PLATFORMS);if(!sh||sh.getLastRow()<2)return[];return sh.getRange(2,1,sh.getLastRow()-1,SMS.PLATFORM_HEADERS.length).getValues().filter(r=>r[0]).map(r=>({platform:String(r[0]),accountName:String(r[1]),allowedFormats:String(r[2]),enabled:String(r[3]).toUpperCase()!=='FALSE',publishingMode:String(r[4]),platformOpeningUrl:String(r[5]),reminderLeadMinutes:Number(r[6]||60),maximumRetries:Number(r[7]||3),credentialStatus:String(r[8]),notes:String(r[9])}));}

function getConfig_(key,fallback){const sh=getSpreadsheet_().getSheetByName(SMS.SHEETS.CONFIG);if(!sh||sh.getLastRow()<2)return fallback;const rows=sh.getRange(2,1,sh.getLastRow()-1,2).getDisplayValues(),found=rows.find(r=>r[0]===key);return found&&found[1]!==''?found[1]:fallback;}

function getCurrentUser_(){const email=Session.getActiveUser().getEmail()||Session.getEffectiveUser().getEmail()||'unknown-user';const sh=getSpreadsheet_().getSheetByName(SMS.SHEETS.TEAM);let role='Viewer';if(sh&&sh.getLastRow()>=2){const rows=sh.getRange(2,1,sh.getLastRow()-1,4).getValues(),match=rows.find(r=>String(r[0]).toLowerCase()===email.toLowerCase()&&String(r[3]).toUpperCase()!=='FALSE');if(match)role=String(match[2]||'Viewer');else if(email===Session.getEffectiveUser().getEmail())role='Admin';}return {email:email,role:role};}
function assertRole_(roles){const u=getCurrentUser_();if(!roles.includes(u.role))throw new Error('Permission denied. Required role: '+roles.join(' / '));return u;}

function getSpreadsheet_(){const id=PropertiesService.getScriptProperties().getProperty('SPREADSHEET_ID');const ss=id?SpreadsheetApp.openById(id):SpreadsheetApp.getActiveSpreadsheet();if(!ss)throw new Error('Spreadsheet not configured. setupSystem() run karein.');return ss;}
function withDocumentLock_(fn){const lock=LockService.getScriptLock();lock.waitLock(30000);try{return fn();}finally{lock.releaseLock();}}
function generateContentId_(){return 'CNT-'+Utilities.formatDate(new Date(),SMS.DEFAULT_TZ,'yyyyMMdd')+'-'+Utilities.getUuid().slice(0,6).toUpperCase();}
function formatDate_(d,pattern){return Utilities.formatDate(d instanceof Date?d:new Date(d),getConfigSafeTz_(),pattern);}
function formatAnyDate_(d){return d instanceof Date?Utilities.formatDate(d,getConfigSafeTz_(),"yyyy-MM-dd'T'HH:mm:ss"):String(d||'');}
function getConfigSafeTz_(){try{return getSpreadsheet_().getSpreadsheetTimeZone()||SMS.DEFAULT_TZ;}catch(e){return SMS.DEFAULT_TZ;}}
function parseDateCell_(s){if(!s)return'';const p=String(s).split('-').map(Number);return new Date(p[0],p[1]-1,p[2],12,0,0);}
function parseTimeCell_(s){if(!s)return'';const p=String(s).split(':').map(Number);return new Date(1899,11,30,p[0],p[1],0);}
function scheduledDate_(item){return zonedDate_(item.scheduledDate,item.scheduledTime,item.timeZone||SMS.DEFAULT_TZ);}
function zonedDate_(date,time,tz){if(!date||!time)return new Date(0);const wall=new Date(date+'T'+time+':00Z');let guess=new Date(wall);for(let i=0;i<2;i++){const shown=Utilities.formatDate(guess,tz,"yyyy-MM-dd'T'HH:mm:ss"),shownAsUtc=new Date(shown+'Z');guess=new Date(guess.getTime()+wall.getTime()-shownAsUtc.getTime());}return guess;}
function parseUpdated_(x){return x.lastUpdated?new Date(x.lastUpdated):new Date(0);}
function startOfWeek_(d){const x=new Date(d),day=(x.getDay()+6)%7;x.setDate(x.getDate()-day);x.setHours(0,0,0,0);return x;}
function extractDriveFileId_(url){const s=String(url||'');const m=s.match(/[-\w]{25,}/);return m?m[0]:'';}
function csvEscape_(v){const s=String(v==null?'':v);return /[",\r\n]/.test(s)?'"'+s.replace(/"/g,'""')+'"':s;}
function escapeHtml_(s){return String(s==null?'':s).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));}
function stripHtml_(s){return String(s).replace(/<[^>]*>/g,' ').replace(/\s+/g,' ').trim();}
function truncate_(s,n){s=String(s||'');return s.length>n?s.slice(0,n-1)+'…':s;}
